import server from "@/utils";
export function UserLoginAPI(username,password){
    return server({
        url:'/login',
        method:'POST',
        data:{
            username,password
        }
    })
}
export function UserRegister(username,password){
    return server({
        url:'/register',
        method:'POST',
        data:{
            username,password
        }
    })
}
// 用户退出
export function UserLogoutAPI(){
    return server({
        url:'/logout',
        method:'POST'
    })
}
import server from "@/utils";
export function uploadsfileAPI(file){
    const fromdata=new FormData()
    fromdata.append('file',file)
    return server({
        url:'/uploads',
        method:'POST',
        data:fromdata,
        headers:{
            'Content-Type':'multipart/form-data'
        }
        
    })
}
export function getfileListAPI(){
    return server({
        url:'/getfileList',
        method:'GET'
    })
}
// 文件下载
export function downloadFileAPI(id){
    return server({
        url:`/downloadFile/${id}`,
        method:'GET',
        responseType:'blob',
        headers: {
            'Accept': 'application/octet-stream'
          }
    })
}
// 文件删除
export function DeleteFileAPI(id){
    return server({
        url:`/deletefile/${id}`,
        method:'POST'
    })
}
// 文件重命名
export function RenameFileAPI(id,newFilename){
    return server({
        url:`/renameFile/${id}`,
        method:'POST',
        data:{newFilename}
    })
}
// 验证文件是否上传
export function verifyFileAPI(hash,filename){
    return server({
        url:'/verify',
        method:'GET',
        params:{hash,filename}
    })
}
// 验证切片是否上传
export function verifyChunkAPI(hash,chunkIndex){
    return server({
        url:'/verifyChunk',
        method:'GET',
        params:{hash,chunkIndex}
    })
}
// 上传文件，切片接口
export function uploadChunkAPI(formData){
    return server({
        url:'/uploadChunk',
        method: 'POST',
        data: formData,
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    })
}
// 合并切片
export function mergeChunksAPI(data) {
    return server({
        url: '/mergeChunks',
        method: 'POST',
        data
    })
}

// 清理分片
export function cleanChunksAPI(hash) {
    return server({
        url: `/cleanChunks`,
        method: 'DELETE',
        params: { hash }
    })
}
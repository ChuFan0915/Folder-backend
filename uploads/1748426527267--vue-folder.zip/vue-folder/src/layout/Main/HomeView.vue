<template>
  <div class="container">
    <header class="header-con"><Header/></header>
    <div class="main">
      <aside class="sidebar">
        <Slide :isCollapse="isCollapse"></Slide>
      </aside>
      <main class="content">
        <router-view></router-view>
      </main>
    </div>
  </div>
</template>
<script setup>
import Header from '@/views/Header/Header.vue';
import Slide from '@/views/Slide/Slide.vue';
import { ref } from 'vue';
const isCollapse = ref(false)
</script>

<style scoped>
.container{
  display: flex;
  height: 100vh;
  flex-direction: column;
  overflow-x: hidden;
}
.header-con{
  height: 60px;
  margin-bottom: 10px;

}
.main{
  flex: 1;
  display: flex;
}
.content{
  margin:10px 0 0 10px;
  flex: 1;
}
  
</style>
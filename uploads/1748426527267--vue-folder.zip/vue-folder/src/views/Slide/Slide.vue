<template>
  <el-aside :width="isCollapse ? '64px' : '200px'" class="slidebar">
    <el-menu
      :collapse="isCollapse"
      background-color="#0BD8A2"
      text-color="#ffffff"
      active-text-color="#ffffff"
      router
      :default-active="activePath"
    >
      <el-menu-item index="/">
        <el-icon>
          <HomeFilled />
        </el-icon>
        <span>首页</span>
      </el-menu-item>
      <el-menu-item index="/files">
        <el-icon>
          <Folder />
        </el-icon>
        <span>文件管理</span>
      </el-menu-item>
      <el-menu-item index="/settings">
        <el-icon><Setting /></el-icon>
        <span>文件设置</span>
      </el-menu-item>
    </el-menu>
  </el-aside>
</template>

<script setup>
import { HomeFilled, Folder, Setting } from "@element-plus/icons-vue";
import { computed } from "vue";
import { useRoute } from "vue-router";
defineProps({
  isCollapse: Boolean,
});
const route = useRoute();
const activePath = computed(() => route.path);
</script>

<style>
.sidebar {
  background-color: #0BD8A2;
  color: black;
  height: 100%;
  transition: width 0.2s;
  margin-top: 10px;
}
.el-menu-item.is-active {
  background-color: #0ac091 !important;
  border-radius: 6px;
  color: #ffffff !important;
}
</style>

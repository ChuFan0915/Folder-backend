<template>
  <div class="user-center">
    <el-card class="user-info-card">
      <div class="user-header">
        <el-avatar :size="100" :src="userstore.avatar" />
        <div class="user-basic-info">
          <h2>{{ userInfo.username }}</h2>
          <p class="user-role">{{ userInfo.role }}</p>
        </div>
      </div>
      <el-divider />
      <div class="user-stats">
        <div class="stat-item">
          <h3>{{ userInfo.uploadCount }}</h3>
          <p>上传文件</p>
        </div>
        <div class="stat-item">
          <h3>{{ userInfo.downloadCount }}</h3>
          <p>下载文件</p>
        </div>
        <div class="stat-item">
          <h3>{{ userInfo.storageUsed }}</h3>
          <p>存储空间</p>
        </div>
      </div>
    </el-card>
    <!-- 用户设置表单 -->
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <span>个人信息设置</span>
          <div class="button-con">
          <el-button type="primary" @click="handleSave">保存修改</el-button>
            <el-button type="primary" @click="backMain">返回主页面</el-button>
            </div>
        </div>
      </template>
      <el-form 
        ref="formRef"
        :model="userForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="用户名" prop="username">
          <el-input v-model="userForm.username" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="userForm.phone" />
        </el-form-item>
        
        <el-form-item label="修改密码">
          <el-button type="primary" link @click="showPasswordDialog">
            修改密码
          </el-button>
        
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 修改密码对话框 -->
    <el-dialog
      v-model="passwordDialogVisible"
      title="修改密码"
      width="30%"
    >
      <el-form
        ref="passwordFormRef"
        :model="passwordForm"
        :rules="passwordRules"
        label-width="100px"
      >
        <el-form-item label="原密码" prop="oldPassword">
          <el-input
            v-model="passwordForm.oldPassword"
            type="password"
            show-password
          />
        </el-form-item>
        
        <el-form-item label="新密码" prop="newPassword">
          <el-input
            v-model="passwordForm.newPassword"
            type="password"
            show-password
          />
        </el-form-item>
        
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input
            v-model="passwordForm.confirmPassword"
            type="password"
            show-password
          />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="passwordDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handlePasswordChange">
            确认修改
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { UserStore } from '@/store/user'
import { useRouter } from 'vue-router'
const router=useRouter()
const userstore=UserStore()
const backMain=()=>{
    router.push('/')
}
// 用户信息
const userInfo = reactive({
  username: '张三',
  role: '普通用户',
  uploadCount: 42,
  downloadCount: 156,
  storageUsed: '2.5GB'
})

// 表单数据
const userForm = reactive({
  username: userInfo.username,
  phone: '13800138000'
})

// 表单验证规则
const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱地址', trigger: 'blur' },
    { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
  ]
}

// 密码修改相关
const passwordDialogVisible = ref(false)
const passwordForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: ''
})

const passwordRules = {
  oldPassword: [
    { required: true, message: '请输入原密码', trigger: 'blur' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, message: '密码长度不能小于6位', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value !== passwordForm.newPassword) {
          callback(new Error('两次输入的密码不一致'))
        } else {
          callback()
        }
      },
      trigger: 'blur'
    }
  ]
}

// 表单引用
const formRef = ref(null)
const passwordFormRef = ref(null)

// 显示密码修改对话框
const showPasswordDialog = () => {
  passwordDialogVisible.value = true
}

// 保存用户信息
const handleSave = async () => {
  if (!formRef.value) return
  
  try {
    await formRef.value.validate()
    // TODO: 调用保存用户信息的API
    ElMessage.success('保存成功')
  } catch (error) {
    console.error('表单验证失败:', error)
  }
}

// 修改密码
const handlePasswordChange = async () => {
  if (!passwordFormRef.value) return
  
  try {
    await passwordFormRef.value.validate()
    // TODO: 调用修改密码的API
    ElMessage.success('密码修改成功')
    passwordDialogVisible.value = false
  } catch (error) {
    console.error('密码修改失败:', error)
  }
}
</script>

<style scoped>
.user-center {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}

.user-info-card {
  margin-bottom: 20px;
}

.user-header {
  display: flex;
  align-items: center;
  gap: 20px;
}

.user-basic-info h2 {
  margin: 0;
  font-size: 24px;
}

.user-role {
  color: #909399;
  margin: 5px 0 0;
}

.user-stats {
  display: flex;
  justify-content: space-around;
  text-align: center;
}

.stat-item h3 {
  margin: 0;
  font-size: 24px;
  color: #409EFF;
}

.stat-item p {
  margin: 5px 0 0;
  color: #909399;
}

.settings-card {
  margin-top: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>
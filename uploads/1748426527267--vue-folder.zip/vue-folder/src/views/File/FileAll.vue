<template>
  <el-upload
    ref="uploadRef"
    :http-request="customUpload"
    :show-file-list="false"
    drag
  >
    <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
    <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
    <template #tip>
      <div class="el-upload__tip">支持最大上传文件大小50MB</div>
    </template>
  </el-upload>

  <el-table :data="fileList" style="width: 100%" class="file-table">
    <el-table-column label="文件名" prop="filename">
      <template #default="{ row }">
        <div class="file-name">
          <el-icon><Document /></el-icon>
          <span>{{ row.filename }}</span>
          <el-tooltip content="下载" placement="top">
            <el-icon class="download-icon" @click.stop="handlerDown(row.id)"
              ><Download
            /></el-icon>
          </el-tooltip>
          <el-tooltip content="删除" placement="top">
            <el-icon class="download-icon" @click="handlerDelete(row.id)">
              <Delete />
            </el-icon>
          </el-tooltip>
          <el-tooltip content="编辑文件名" placement="top">
            <el-icon class="download-icon" @click="handlerRename(row)">
              <Edit />
            </el-icon>
          </el-tooltip>
        </div>
      </template>
    </el-table-column>
    <el-table-column prop="fileSize" label="大小">
      <template #default="{ row }">
        {{ formatFileSize(row.size) }}
      </template>
    </el-table-column>
    <el-table-column prop="upload_time" label="上传时间">
      <template #default="{ row }">
        {{ handerTime(row.upload_time) }}
      </template>
    </el-table-column>
  </el-table>
  <el-dialog v-model="isRename" title="文件重命名" width="30%">
    <el-input v-model="renameForm.name"></el-input>
    <template #footer>
      <el-button @click="isRename = false" type="warning">取消</el-button>
      <el-button @click="HanderFileReanme">确定</el-button>
    </template>
  </el-dialog>
  <el-dialog v-model="IsOnProgress" title="上传文件进度">
    <el-progress
      :percentage="uploadProgress"
      status="success"
      :format="progressFormat"
    ></el-progress>
    <div class="upload-info">
      <span>{{ currentFile?.name }}</span>
      <span>{{ formatFileSize(currentFile?.size || 0) }}</span>
    </div>
  </el-dialog>
</template>
<script setup>
import { ref, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import {
  UploadFilled,
  Document,
  Download,
  Delete,
  Edit,
} from "@element-plus/icons-vue";
import { BigFileUpload } from "@/utils/bigFileUpload";
import {
  uploadsfileAPI,
  getfileListAPI,
  downloadFileAPI,
  DeleteFileAPI,
  RenameFileAPI,
} from "@/assets/api/file";

const uploadRef = ref(null);
const fileList = ref([]);
const IsOnProgress = ref(false);
const uploadProgress = ref(0);
const currentFile = ref(null);
// 代表接收当前大文件的对象

// 自定义上传方法
const progressFormat = (percentage) => {
  return percentage === 100 ? "上传完成" : `${percentage}%`;
};
const customUpload = async (options) => {
  const file = options.file;
  currentFile.value = file;
  try {
    if (file.size > 50 * 1024 * 1024) {
      // 构造一个对象函数
      IsOnProgress.value = true;
      uploadProgress.value = 0;
      const uploader = new BigFileUpload(file, {
        onProgress: (progress) => {
          uploadProgress.value = progress;
        },
      });
      await uploader.upload();
      IsOnProgress.value = false;
      getFileList();
    } else {
      const response = await uploadsfileAPI(options.file);
      if (response.code === 0) {
        ElMessage.success("上传成功");
        options.onSuccess(response);
        // 上传成功后刷新列表
        getFileList();
      }
    }
  } catch (error) {
    options.onError(error);
    ElMessage.error("上传失败，请稍后再试");
  }
};

// 获取文件列表
const getFileList = async () => {
  try {
    const res = await getfileListAPI();
    if (res.code === 0) {
      fileList.value = res.data;
    } else {
      ElMessage.error(res.message || "获取文件列表失败");
    }
  } catch (error) {
    console.error("获取文件列表错误:", error);
    ElMessage.error("获取文件列表失败");
  }
};

// 格式化文件大小
const formatFileSize = (size) => {
  if (!size) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index++;
  }
  return `${size.toFixed(2)} ${units[index]}`;
};
// 上传时间处理
const handerTime = (time) => {
  return time.split("T")[0];
};
// 文件下载
// 假设 downloadFileAPI 已经设置 responseType: 'blob'
// 命名函数用来提取文件名字
function getfolderName(disposition) {
  if (!disposition) return "未命名文件";
  // 其他格式
  const rfc5987Match = /filename\*=UTF-8''([^;]+)/i.exec(disposition);
  if (rfc5987Match) return decodeURIComponent(rfc5987Match[1]);

  // 普通格式：filename="xxx" 或 filename=xxx
  const fallbackMatch = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(
    disposition
  );
  if (fallbackMatch)
    return decodeURIComponent(fallbackMatch[1].replace(/['"]/g, ""));
  return "未命名文件";
}
async function handlerDown(id) {
  try {
    const response = await downloadFileAPI(id);
    const disposition = response.headers["content-disposition"];
    const filename = getfolderName(disposition);
    const blob = new Blob([response.data], {
      type: response.headers["content-type"],
    });
    const url = URL.createObjectURL(blob);
    //  生成下载链接
    const link = Object.assign(document.createElement("a"), {
      href: url,
      download: filename,
    });
    document.body.appendChild(link);
    link.click();
    // 下载完清理链接
    setTimeout(() => {
      URL.revokeObjectURL(url);
      document.body.removeChild(link);
    }, 100);
    ElMessage.success("下载成功");
  } catch (error) {
    console.error("下载失败：", error);
    ElMessage.error("下载失败，请稍后重试");
  }
}
// 文件删除
const handlerDelete = async (id) => {
  try {
    await ElMessageBox.confirm("确定要删除该文件吗？", "删除提示", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    });
    const res = await DeleteFileAPI(id);
    if (res.code === 0) {
      ElMessage.success("删除成功");
      getFileList();
    }
  } catch (e) {
    console.log(e);
    ElMessage.error("删除文件失败，请稍后再试");
  }
};
// 文件重命名
const renameForm = ref({
  id: null,
  name: "",
});
const isRename = ref(false);
const handlerRename = (file) => {
  renameForm.value.id = file.id;
  renameForm.value.name = file.filename;
  isRename.value = true;
};
const HanderFileReanme = async () => {
  if (!renameForm.value.name.trim()) {
    ElMessage.error("文件名不能为空");
    return;
  }
  try {
    const res = await RenameFileAPI(renameForm.value.id, renameForm.value.name);
    if (res.code === 0) {
      getFileList();
      ElMessage.success("重命名成功");
      isRename.value = false;
    }
  } catch (e) {
    console.log(e);
    ElMessage.error("重命名失败，请稍后再试");
  }
};
onMounted(() => {
  getFileList();
});
</script>

<style scoped>
.el-upload {
  width: 100%;
  margin-bottom: 20px;
}

.el-upload-dragger {
  width: 100%;
}

.el-upload__tip {
  margin-top: 10px;
  color: #909399;
}

.file-name {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-right: 20px;
}

.file-name .el-icon {
  font-size: 16px;
  color: #909399;
}
.file-table {
  margin-top: 10px;
}
.download-icon,
.download-icon-text {
  margin-left: 10px;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.3s;
  font-size: 18px !important;
  color: skyblue !important;
}

/* 因为icon图标是svg，所以不会继承 */
.file-name:hover .download-icon {
  opacity: 1;
}
</style>

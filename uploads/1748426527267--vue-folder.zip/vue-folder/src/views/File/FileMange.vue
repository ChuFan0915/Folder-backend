<template>
  <div>这是文件管理</div>
</template>

<script setup>
  
</script>

<style>
  
</style>
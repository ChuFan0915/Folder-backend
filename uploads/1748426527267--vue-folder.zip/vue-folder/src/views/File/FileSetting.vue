<template>
  <div>这是文件设置</div>
</template>

<script setup>
  
</script>

<style>
  
</style>
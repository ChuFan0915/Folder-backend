<template>
  <div class="container">
    <video autoplay muted loop playsinline class="bg-video">
      <source src="@/assets/images/bg.mp4">
    </video>
    <div class="login-form">
      <h2 class="con-header">文件上传管理系统</h2>
      <el-form ref="ruleFormRef" style="max-width: 600px" :model="ruleForm" :rules="rules">
   <BaseInput
  v-model="ruleForm.username"
  label="账户"
  placeholder="请输入账户"
  
>
  <template #icon>
    <el-icon><User /></el-icon>
  </template>
</BaseInput>
     <BaseInput v-model="ruleForm.password" label="密码" placeholder="请输入密码" type="password"
         >
          <template #icon>
            <el-icon>
              <Lock />
            </el-icon>
          </template>
        </BaseInput>
    <BaseButton :loading="loading" @action="HandLogin"></BaseButton>
      </el-form>
    </div>
  </div>
</template>
<script setup>
import { ref } from "vue";
import { ElMessage } from "element-plus";
import { useRouter } from "vue-router";
import BaseInput from "./BaseInput.vue";
import { User, Lock } from '@element-plus/icons-vue'
import BaseButton from "./BaseButton.vue";
import { UserRegister,UserLoginAPI } from "@/assets/api/user";
import { UserStore } from "@/store/user";
const userstore=UserStore()
const router = useRouter()
const loading=ref('')
const ruleFormRef = ref(null)
const ruleForm = ref({
  username: '',
  password: '',
})
const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' }
  ]
}
// 登录
const HandLogin =(type) => {
  ruleFormRef.value.validate( async (value) => {
    if (value) {
    if(type==='login'){
      const res=await UserLoginAPI(ruleForm.value.username,ruleForm.value.password)
      console.log(res);
      if(res.code===0){
      userstore.setUserInfo()
          router.push('/')
        ElMessage.success('登录成功')
      }else{
        ruleForm.value.username=''
        ruleForm.value.password=''
        ElMessage.error('账户密码好像不太对哦')
      }
   
    }else if(type==='register'){
      const res=await UserRegister(ruleForm.value.username,ruleForm.value.password)
      if(res.code===0){
        ElMessage.success('注册成功，请返回登录')
        ruleForm.value.username=''
        ruleForm.value.password=''
      }
    }
    } else {
      ElMessage.warning("请填写完整信息！");
    }
  })

}
</script>
<style scoped>
body {
  margin: 0;
  padding: 0;
}

.container {
  height: 100vh;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.bg-video {
  height: 100%;
  object-fit: cover;
  width: 100%;
  position: fixed;
  z-index: -1;
  top: 0;
  left: 0;
}

.con-header {
  font-size: 20px;
  color: white;
  margin-bottom: 10px;

}

.login-form {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 400px;
  margin-left: 400px;
  height: 200px;
  background-color: black;
  opacity: 0.8;
  border-radius: 30px;
}

.el-button {
  display: block;
  margin: 0 auto;

}
</style>
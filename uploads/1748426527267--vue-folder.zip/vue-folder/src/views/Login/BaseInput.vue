    <template>
        <el-form-item :label="label">
            <el-input :type="type === 'password' ? innerType : 'text'" :placeholder="placeholder"
                :model-value="modelValue" @update:modelValue="$emit('update:modelValue', $event)" clearable>
                <!-- 插槽，插入图表 -->
                <template #prefix>
                    <slot name="icon"></slot>
                </template>
                <template #suffix v-if="type === 'password'">
                    <el-icon @click="changeView">
                        <component :is="innerType === 'password' ? View : Hide"></component>
                    </el-icon>
                </template>
            </el-input>
        </el-form-item>
    </template>

<script setup>
import { ref } from 'vue';
import { View, Hide } from '@element-plus/icons-vue'
defineProps({
    type: {
        type: String,
        default: "text"
    },
    placeholder: String,
    label: String,
    modelValue: [String, Number],
})
defineEmits(["update:modelValue"])
const innerType = ref('password')
const password = ref('')
const changeView = () => {
    innerType.value = innerType.value === 'password' ? 'text' : 'password'
}
</script>

<style scoped>
.el-input {
    width: 200px;
}
</style>
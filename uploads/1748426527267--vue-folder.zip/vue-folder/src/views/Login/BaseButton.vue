<template>
  <div class="btn-container">
  <el-button type="primary" :loading="loading === 'login'" @click="handClick('login')">登录</el-button>
  <el-button :loading="loading === 'register'" @click="handClick('register')">注册</el-button>
  </div>
</template>

<script setup>
  defineProps({
    loading:String
  })
  const emit = defineEmits(['action'])
  const handClick=(type)=>{
    emit('action',type)
  }
</script>
<style scoped>
  .btn-container{
    display: flex;
    justify-content: space-between;
  }
</style>
<template>
  <div class="header-container">
    <div class="left">
      <img src="@/assets/images/yp.svg" alt="" />
      <h2 class="header-tittle">24岁的盘</h2>
    </div>
    <div class="right">
      <el-dropdown>
        <span class="el-dropdown-link">
          <el-avatar size="large" :src="userstore.avatar" />
        </span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="handerUser">个人中心</el-dropdown-item>
            <el-dropdown-item @click="handerBack">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from "vue-router";
import { UserStore } from "@/store/user";
import { UserLogoutAPI } from "@/assets/api/user";
import { ElMessage, ElMessageBox } from "element-plus";

const userstore = UserStore();
const router = useRouter();
const handerUser = () => {
  router.push("/user");
};
const handerBack = async () => {
  try {
    await ElMessageBox.confirm("确定要退出登录吗", "退出提示", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    });
    const res = await UserLogoutAPI();
    if (res.code === 0) {
      userstore.userlogout();
      ElMessage.success("退出登录成功");
      router.push("/login");
    }
  } catch (e) {
    console.log(e);
  }
};
</script>

<style scoped>
.header-container {
  display: flex;
  justify-content: space-around;
  height: 100%;
  width: 100%;
  margin-top: 10px;
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  border-bottom: 1px solid #f0f0f0;
}

.left {
  flex: 1;
  display: flex;
  gap: 20px;
  align-items: center;
}

.left img {
  width: 60px;
  height: 60px;
  margin-left: 10px;
}

.right {
  display: flex;
  align-items: center;
}

.el-dropdown-link {
  margin-right: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  outline: none;
}

.el-avatar {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease;
}

.el-avatar:hover {
  transform: scale(1.05);
}

.header-tittle {
  font-family: "ZCOOL KuaiLe", sans-serif;
  color: #0bd8a2;
  font-size: 26px;
  cursor: pointer;
}
</style>

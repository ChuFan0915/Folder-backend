import { verifyChunkAPI,verifyFileAPI,uploadChunkAPI,mergeChunksAPI,cleanChunksAPI} from "@/assets/api/file";
import { ElMessage } from "element-plus";
export class BigFileUpload{
    constructor(file,options={}){
        this.file=file
        this.chunkSize=options.chunkSize||5*1024*1024//5mb
        this.chunks=Math.ceil(file.size/this.chunkSize)
        // 分了几片文件的切片
        this.currentChunk=0
        // 当前的切片页数
        this.hash=''
        this.onProgress=options.onProgress(()=>{})
    }
    // 生成文件的hash
    async calculateHash(){
        return `${Date.now()}--${this.file.name}--${this.file.size}`
    }
    // 创建文件的切片 ---chunk
    async createChunk(start){
        return this.file.splice(start,start+this.chunkSize)
    }
    // 上传单个的切片文件
    async uploadChunk(chunk,index){
        const formData=new FormData()
        formData.append('chunk',chunk)
        // 切片本地
        formData.append('hash',this.hash)
        // 每一页的切片标识
        formData.append('chunkIndex',index)
        // 切片的索引
        formData.append('totalChunk',this.chunks)
        // 总的切片页数
        try{
            const response=await uploadChunkAPI(formData)
            this.currentChunk++
            // 进度条的写法
            // 当前的页数➗总的chunks数
            this.onProgress=Math.round((this.currentChunk/this.chunks)*100)
            return response
        }catch(error){
            throw new error('文件分片上传失败')
        }
    }
    // 开始上传
    async upload(){
        try{
            this.hash=await this.calculateHash()
            const verifyResult=await verifyFileAPI(this.hash,this.file.name)
                 if (verifyResult.data?.exists) {
                ElMessage.success('文件秒传成功！')
                return verifyResult
            }
            const tasks=[]
            let start=0
            // 切片上传的逻辑
            // 1:遍历整个切片数量,看看有无上传重复的切片
            for(let i =0;i<this.chunks.length;i++){
                const exists=verifyChunkAPI(this.hash,i)
                if(!exists.data.exists){
                    // 2:如果切片不存在，就添加进tasks里面
                    const chunk=this.createChunk(start)
                    tasks.push(this.uploadChunk(chunk,i))
                }else{
                    this.currentChunk++
                    this.onProgress=Math.round((this.currentChunk/this.chunks)*100)
                }
                start +=this.chunkSize
            }
            await Promise.all(tasks)
            // 这句话有点没看懂
            // 合并接口
            const mergeChunksRes=await mergeChunksAPI({
                hash:this.hash,
                filename:this.file.name,
                mimetype: this.file.type,
                totalChunks: this.chunks
            })
            if(mergeChunksRes.code===0){
                ElMessage.success('文件上传成功')
            }
            return mergeChunksRes
        }catch (error) {
            this.onError(error)
            // 清理分片
            await cleanChunksAPI(this.hash).catch(console.error)
            throw error

    }
}
}
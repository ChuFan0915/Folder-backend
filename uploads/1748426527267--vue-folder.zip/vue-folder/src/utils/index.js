import axios from "axios";
const server=axios.create({
    baseURL:'http://192.168.124.55:3000',
    timeout:15000,
    headers:{
      'Content-Type':'application/json'
    }
})
server.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    console.error('Request Error:', error);
    return Promise.reject(error)
  }
)

// 响应拦截器：统一处理返回结果和错误
server.interceptors.response.use(
  (response) => {
       if (response.config.responseType === 'blob') {
      return response;
    }
    const res = response.data
    if (res.success === false) {
      ElMessage.error(res.message || '请求失败')
      return Promise.reject(res)
    }
    return res
  },
  (error) => {
    console.error('Response Error:', error);
    if (error.response) {
      const { status, data } = error.response
      ElMessage.error(data.message || `请求错误：${status}`)
    } else {
      ElMessage.error('网络错误或服务器无响应')
    }
    return Promise.reject(error)
  }
)

export default server
import { defineStore } from "pinia";
import avatarPath from '@/assets/images/justin.jpg'
export const UserStore=defineStore('user',{
    state:()=>({
        username:'',
        avatar:avatarPath,
        LoginToken:false
    }),
    actions:{
        // 修改头像
        setAvatar(avatar){
            this.avatar=avatar
        },
        // 修改登录状态
        setUserInfo(){
            this.LoginToken=true
        },
        userlogout(){
            this.LoginToken=false
        }


    },
    persist: true

})
import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../layout/Main/HomeView.vue'
import LoginIndex from '@/views/Login/LoginIndex.vue'
import FileAll from '@/views/File/FileAll.vue'
import FileMange from '@/views/File/FileMange.vue'
import FileSetting from '@/views/File/FileSetting.vue'
import UserCenter from '@/views/User/UserCenter.vue'
import { UserStore } from '@/store/user'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
      meta:{requiresAuth:true},//定义一个meta字段
      children:[
        {
          path:'',
          name:'fileall',
          component:FileAll
        },
        {
          path:'files',
          name:'files',
          component:FileMange
        },
        {
          path:'settings',
          name:'setting',
          component:FileSetting
        }
      ]
    },
    {
      path:'/login',
      name:'login',
      component:LoginIndex
    },
    {
      path:'/user',
      name:'user',
      component:UserCenter,
       meta:{requiresAuth:true}
    }
  ],
})
router.beforeEach((to, from, next) => {
  const userstore = UserStore()
  if (to.meta.requiresAuth) {
    if (!userstore.LoginToken) {
      next({ name: 'login', query: { redirect: to.fullPath } }) 
    } else {
      next()
    }
  } else {
    next()
  }
})

export default router
